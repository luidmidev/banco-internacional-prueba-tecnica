package ec.com.bancointernacional.pruebatecnica.schemas;

public enum AccountType {
    SAVINGS, // Cuenta de Ahorros
    CHECKING // Cuenta Corriente
}

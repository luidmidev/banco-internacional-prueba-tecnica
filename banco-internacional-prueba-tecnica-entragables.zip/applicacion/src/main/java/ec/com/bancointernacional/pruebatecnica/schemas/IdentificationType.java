package ec.com.bancointernacional.pruebatecnica.schemas;

public enum IdentificationType {
    RUC,
    CI,
    PASSPORT
}

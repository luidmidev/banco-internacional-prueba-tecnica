package ec.com.bancointernacional.pruebatecnica.schemas;

public enum AccountStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED,
    CLOSED
}
